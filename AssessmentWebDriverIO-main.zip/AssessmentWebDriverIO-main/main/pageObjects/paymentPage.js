/*
Page - Payment --> Validate the page
*/

const allureReporting = require('@wdio/allure-reporter').default
const {waitForElementDisplayed, scrollToView}=require('../common/commonFunctions')

class paymentPage{
 
    get txt_productConfirmation(){return $("//td[@class='cart_description']/p[@class='product-name']/a")}
   
   /*
   Validation
   */
    verifyProduct(){
        allureReporting.startStep('Validation on Payments page')
        waitForElementDisplayed(this.txt_productConfirmation)
        scrollToView(this.txt_productConfirmation)
        return this.txt_productConfirmation
    }
}

module.exports = new paymentPage()