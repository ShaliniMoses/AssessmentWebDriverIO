/*
Page - CartPage --> Perform Checkout
*/
const { default: AllureReporter } = require("@wdio/allure-reporter")
const { waitForElementDisplayed, doClick, scrollToView,waitForElementExists } = require('../common/genericMethods')

class cartPage {

    get btn_proceedToChkout2() { return $("(//span[contains(text(),'Proceed to checkout')])[last()]") }
    get btn_agreement() { return $("//label[contains(text(),'I agree')]/preceding::input[1]") }

    performProceedToCheckoutinCartPage() {
        AllureReporter.addStep('Checkout the Product')
        AllureReporter.startStep('Next -- >Summary Page')
        //Summary 
        this.performProceedToChkout()
        AllureReporter.startStep('Next -- > Address page')
        // Address Page
        this.performProceedToChkout()
        AllureReporter.startStep('Next -- > Shipping page')
        // Shipping page
        scrollToView(this.btn_agreement)
        this.btn_agreement.click()
        this.performProceedToChkout()
        AllureReporter.endStep()
    }

    performProceedToChkout() {
        waitForElementExists(this.btn_proceedToChkout2)
        this.btn_proceedToChkout2.scrollIntoView()
        this.btn_proceedToChkout2.click()
    }

}
module.exports = new cartPage()