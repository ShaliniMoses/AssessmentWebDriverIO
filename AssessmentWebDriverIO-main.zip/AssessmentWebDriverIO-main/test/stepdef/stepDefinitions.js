const { Given, When, Then } = require('@cucumber/cucumber')
const allureReporting = require('@wdio/allure-reporter').default
const homePage = require('../main/pageObjects/homePage');
const registerPage = require('../main/pageObjects/registerPage')
const baseSetup = require('../main/common/baseSetup')
const commonFunctions = require('../main/common/genericMethods')
const testdata = require('../resources/testdata');
const productPage = require('../main/pageObjects/productPage');
const cartPage = require('../main/pageObjects/cartPage');
const paymentPage = require('../main/pageObjects/paymentPage');



Given(/^The URL for registration$/, () => {
    baseSetup.openUrl()
});


When(/^I perform user registration$/, () => {
    let email = commonFunctions.generateRandomEmailId(4);
    console.log('Mail Id: '+email)

    homePage.performSignUp()

    registerPage.initiateRegistration(email)

    registerPage.enterDetailsAndSubmit(testdata.firstname, testdata.lastname, email,
        testdata.password, testdata.bday, testdata.bmonth, testdata.byr, testdata.company,
        testdata.address, testdata.city, testdata.state, testdata.postcode, testdata.mobile)

});

Then(/^User registration is successful$/, () => {
    allureReporting.addStep('User Registration Successful')
    let registeredName = registerPage.validateSuccessfulRegistration()
    expect(registeredName).toHaveText(testdata.firstname+" "+testdata.lastname)
    allureReporting.startStep('Confirmed successful user registration')
    allureReporting.endStep()
});

Then(/^The User is logged in to the application$/, () => {
    allureReporting.addStep('User Logging in')
    
    allureReporting.startStep('User Logged in successfully')
    allureReporting.endStep()
});

When(/^I try to add the product to the cart$/, () => {
    homePage.searchForProduct(testdata.product)
    console.log('Step 1: Product Searched as expected')
    productPage.addToCart(testdata.product)
    console.log('Step 2: Product Added to the Cart')

    cartPage.performProceedToCheckoutinCartPage()
    console.log('Step 3: Checking out the Product')

});

Then(/^Validate the payment page for the product added$/, () => {
    allureReporting.addStep('Validate the payment page for the added product')
    let actualProductPicked = paymentPage.verifyProduct()
    expect(actualProductPicked).toHaveText(testdata.product)
    allureReporting.startStep('Product has been confimed to be as expected')
    allureReporting.endStep()
    console.log('Step 4: Validation done')
});